#include <stdlib.h>
#include <stdio.h>
#include "answer01.h"

int arraySum(int * array, int len)
{
    int i;
    int sum = 0;

    if(array == NULL)
	return 0;

    for(i = 0; i < len; i++)
    {
	sum += array[i];
    }

    return sum;
}

int arrayCountNegative(int * array, int len)
{
    int i; 
    int negCount = 0;

    if(array == NULL)
	return 0;

    for(i = 0; i < len; i++)
    {
    	if(array[i] < 0)
	{
	    negCount++;
	}
    }

    return negCount;
}

int arrayIsIncreasing(int * array, int len)
{
    int i;
    
    if(array == NULL)
	return 0;

    for(i = 0; i < len - 1; i++)
    {
	if(array[i] > array[i + 1])
	    return 0;
    }

    return 1;
}

int arrayIndexRFind(int needle, const int * haystack, int len)
{    
    if(haystack == NULL)
	return 0;
   
    int i;
    int foundIndex = -1;
    
    for(i = 0; i < len; i++)
    {
	if(needle == haystack[i])
	{
	    foundIndex = i;
	}
    }

    return foundIndex;
}

int arrayFindSmallest(int * array, int len)
{
    if(array == NULL)
	return 0;

    if(len == 0)
        return 0;

    int i;
    int smallest = array[0];
    int smallestInd = 0;

    for(i = 1; i < len; i++)
    {
	if(array[i] < smallest)
	{
	    smallest = array[i];
	    smallestInd = i;
	}
    }

    return smallestInd;
}
